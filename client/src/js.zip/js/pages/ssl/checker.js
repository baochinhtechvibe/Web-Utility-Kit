// ===================================================
//  SSL TOOLS - MAIN SCRIPT
// ===================================================


// ===================================================
//  CONFIGURATION
// ===================================================

/**
 * Base URL của Backend API
 */
const API_BASE_URL = "http://localhost:3102/api";


// ===================================================
//  TOOL MENU BUTTONS (Sidebar / Toolbar)
// ===================================================
const toolMenuButtons = document.querySelectorAll(".js-tool-btn");
const btnToolChecker = document.getElementById("btnToolChecker");
const btnToolCsr = document.getElementById("btnToolCsr");
const btnToolCert = document.getElementById("btnToolCert");
const btnToolMatcher = document.getElementById("btnToolMatcher");
const btnToolConverter = document.getElementById("btnToolConverter");
// ===================================================
//  TOOL CONTAINERS (Tool Panels / Sections)
// ===================================================
const toolChecker = document.getElementById("toolChecker");
const toolCsr = document.getElementById("toolCsr");
const toolCert = document.getElementById("toolCert");
const toolMatcher = document.getElementById("toolMatcher");
const toolConverter = document.getElementById("toolConverter");
// ===================================================
//  SSL CHECKER FORM ELEMENTS
// ===================================================
const formChecker = document.getElementById("formChecker");
const inputChecker = document.getElementById("inputChecker");
const btnSubmitChecker = document.getElementById("btnSubmitChecker");
const iconCheckerArrow = document.getElementById("iconCheckerArrow");
const iconCheckerLoading = document.getElementById("iconCheckerLoading");
const sslCheckerResultBox = document.getElementById("ssl-checker-results");


// ===================================================
//  UI HELPER FUNCTIONS
// ===================================================

/**
 * Thay đổi display của element bằng utility class
 * @param {HTMLElement} element
 * @param {string} mode - none | block | flex | inline | inline-block
 */
function setDisplay(element, mode = "none") {
    if (!element) return;

    const displayClasses = [
        "d-none",
        "d-block",
        "d-flex",
        "d-inline",
        "d-inline-block"
    ];

    // Remove toàn bộ class display cũ
    element.classList.remove(...displayClasses);

    // Add class display mới
    if (mode) {
        element.classList.add(`d-${mode}`);
    }
}


/**
 * Hiển thị nhiều element cùng lúc
 * @param {string} mode
 * @param  {...HTMLElement} elements
 */
function showElements(mode, ...elements) {
    elements.forEach(el => setDisplay(el, mode));
}


/**
 * Hiển thị trạng thái loading khi submit form
 */
function showSubmitLoading() {
    setDisplay(iconCheckerArrow, "none");
    setDisplay(iconCheckerLoading, "inline-block");

    btnSubmitChecker.disabled = true;
}


/**
 * Tắt trạng thái loading sau khi xử lý xong
 */
function hideSubmitLoading() {
    setDisplay(iconCheckerArrow, "inline-block");
    setDisplay(iconCheckerLoading, "none");

    btnSubmitChecker.disabled = false;
}

