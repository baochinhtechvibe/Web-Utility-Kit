/*
===============================================
    URL UTILITIES FUNCTIONS
    Các hàm xử lý URL, link, API
=================================================
*/
/**
 * Get IP info link
 */
export function getIPInfoLink(ip) {
    return `https://check-host.net/ip-info?host=${ip}`;
}