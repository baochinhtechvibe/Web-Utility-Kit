package models

import "time"

/* ===========================
   TLS Scan Result
=========================== */

type TLSScanResult struct {
	Version string `json:"version"`
	Cipher  string `json:"cipher"`
	Secure  bool   `json:"secure"`
}

/* ===========================
   Certificate Detail
=========================== */

type CertDetail struct {
	CommonName string `json:"common_name"`
	Issuer     string `json:"issuer"`

	Organization []string `json:"organization,omitempty"`
	Country      []string `json:"country,omitempty"`

	SANs []string `json:"sans"`

	NotBefore time.Time `json:"not_before"`
	NotAfter  time.Time `json:"not_after"`

	SerialNumberDec string `json:"serial_dec"`
	SerialNumberHex string `json:"serial_hex"`

	SignatureAlgo string `json:"signature_algo"`

	FingerprintSHA1   string `json:"fingerprint_sha1"`
	FingerprintSHA256 string `json:"fingerprint_sha256"`

	IsCA bool `json:"is_ca"`
}

/* ===========================
   Main SSL Response
=========================== */

type SSLCheckResponse struct {

	/* ---- Basic Info ---- */

	Hostname string `json:"hostname"`
	IP       string `json:"ip"`

	ServerType string `json:"server_type"`

	/* ---- Validity ---- */

	Valid    bool `json:"valid"`
	DaysLeft int  `json:"days_left"`

	/* ---- Verification ---- */

	HostnameOK bool `json:"hostname_ok"`
	Trusted    bool `json:"trusted"`

	OCSPGood bool `json:"ocsp_good"`

	/* ---- TLS ---- */

	TLSVersion string          `json:"tls_version"`
	TLSScan    []TLSScanResult `json:"tls_scan"`

	/* ---- Grade ---- */

	Grade  string `json:"grade"`
	Status string `json:"status"` // ok | warning | critical

	/* ---- Chain ---- */

	CertChain []CertDetail `json:"cert_chain"`

	/* ---- Meta ---- */

	CheckTime time.Time `json:"check_time"`
}
