package checker

import (
	"encoding/json"
	"log"
	"net/http"
	"time"

	"tools.bctechvibe.io.vn/server/ssl/internal/platform/shared"
)

type Handler struct {
	svc *Service
}

type CheckRequest struct {
	Domain string `json:"domain"`
}

func NewHandler() *Handler {
	return &Handler{
		svc: New(),
	}
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	startTime := time.Now()
	defer func() {
		duration := time.Since(startTime)
		log.Printf("[%s] %s %s - took %v", r.Method, r.RequestURI, r.RemoteAddr, duration)
	}()

	// Support both GET and POST
	var domain string

	if r.Method == http.MethodGet {
		domain = r.URL.Query().Get("domain")
	} else if r.Method == http.MethodPost {
		var req CheckRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			log.Printf("Failed to decode request body: %v", err)
			shared.Error(w, "Invalid request body", http.StatusBadRequest)
			return
		}
		domain = req.Domain
	} else {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	d := shared.NormalizeDomain(domain)

	if !shared.ValidDomain(d) {
		log.Printf("Invalid domain: %s (normalized: %s)", domain, d)
		shared.Error(w, "Invalid domain format", http.StatusBadRequest)
		return
	}

	res, err := h.svc.Check(d)

	if err != nil {
		if err == shared.ErrBlocked {
			log.Printf("Domain blocked (rate limited or circuit breaker): %s", d)
			shared.Error(w, err.Error(), http.StatusTooManyRequests)
			return
		}

		log.Printf("SSL check failed for %s: %v", d, err)
		shared.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	shared.JSON(w, res)
}
