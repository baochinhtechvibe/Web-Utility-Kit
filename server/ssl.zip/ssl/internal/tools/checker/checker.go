package checker

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"errors"
	"fmt"
	"log"
	"net"
	"time"

	"tools.bctechvibe.io.vn/server/ssl/internal/config"
	"tools.bctechvibe.io.vn/server/ssl/internal/models"
)

func resolveIP(domain string) (string, error) {

	ips, err := net.LookupIP(domain)
	if err != nil {
		return "", fmt.Errorf("DNS lookup failed: %w", err)
	}

	// Prefer IPv4
	for _, ip := range ips {
		if v4 := ip.To4(); v4 != nil {
			return v4.String(), nil
		}
	}

	// Fallback to IPv6 global (skip link-local)
	for _, ip := range ips {
		if ip.To16() != nil && !ip.IsLinkLocalUnicast() {
			return ip.String(), nil
		}
	}

	return "", errors.New("no valid IP found")
}

// detectTLSVersion returns TLS version string
func detectTLSVersion(state tls.ConnectionState) string {
	switch state.Version {
	case tls.VersionTLS13:
		return config.TLSVersion13
	case tls.VersionTLS12:
		return config.TLSVersion12
	case tls.VersionTLS11:
		return config.TLSVersion11
	case tls.VersionTLS10:
		return config.TLSVersion10
	default:
		return "Unknown"
	}
}

// calcStatus calculates certificate status
func calcStatus(
	valid bool,
	daysLeft int,
	trusted bool,
	hostnameOK bool,
	ocspGood bool,
	tlsVersion string,
) string {
	// Critical issues
	if !valid || !trusted || !hostnameOK {
		return config.StatusCritical
	}

	// Warning issues
	if daysLeft < config.CertExpirySoonThreshold {
		return config.StatusWarning
	}

	if tlsVersion != config.TLSVersion13 && tlsVersion != config.TLSVersion12 {
		return config.StatusWarning
	}

	if !ocspGood {
		return config.StatusWarning
	}

	return config.StatusOK
}

/* ===========================
   Main Scanner
=========================== */

func Scan(
	ctx context.Context,
	domain string) (
	*models.SSLCheckResponse, error) {

	// Check context first
	select {
	case <-ctx.Done():
		return nil, ctx.Err()
	default:
	}

	// Resolve IP
	ip, err := resolveIP(domain)
	if err != nil {
		return nil, fmt.Errorf("failed to resolve IP: %w", err)
	}

	// Detect server type
	serverType := detectServerType(domain)

	// TLS Dial with context timeout
	dialer := &net.Dialer{
		Timeout: config.TLSDialTimeout,
	}

	conn, err := tls.DialWithDialer(
		dialer,
		"tcp",
		domain+":443",
		&tls.Config{
			ServerName: domain,
		},
	)

	if err != nil {
		return nil, fmt.Errorf("TLS dial failed: %w", err)
	}
	defer conn.Close()

	// Get TLS connection state
	state := conn.ConnectionState()
	certs := state.PeerCertificates

	if len(certs) == 0 {
		return nil, errors.New("no certificates found in chain")
	}

	// Get TLS version
	tlsVersion := detectTLSVersion(state)

	// Verify hostname
	hostnameOK := certs[0].VerifyHostname(domain) == nil

	// Verify chain
	err = verifyChainOffline(certs)
	trusted := err == nil
	if !trusted {
		log.Printf("Chain verification failed: %v", err)
	}

	// Check OCSP
	ocspGood := false
	if len(certs) >= 2 {
		ocspGood = checkOCSP(certs[0], certs[1])
	}

	// TLS scan (versions + ciphers)
	tlsScan := scanTLS(domain)

	// Build certificate chain
	chain := buildCertChain(certs)

	// Calculate expiry
	mainCert := certs[0]
	daysLeft := int(time.Until(mainCert.NotAfter).Hours() / 24)
	valid := daysLeft > 0

	// Calculate grade and status
	grade := calcGrade(tlsVersion, daysLeft, trusted, ocspGood)
	status := calcStatus(valid, daysLeft, trusted, hostnameOK, ocspGood, tlsVersion)

	return &models.SSLCheckResponse{
		Hostname:   domain,
		IP:         ip,
		ServerType: serverType,
		Valid:      valid,
		DaysLeft:   daysLeft,
		TLSVersion: tlsVersion,
		TLSScan:    tlsScan,
		HostnameOK: hostnameOK,
		Trusted:    trusted,
		OCSPGood:   ocspGood,
		Grade:      grade,
		Status:     status,
		CertChain:  chain,
		CheckTime:  time.Now(),
	}, nil
}

// buildCertChain builds certificate details from chain
func buildCertChain(certs []*x509.Certificate) []models.CertDetail {
	var chain []models.CertDetail

	for _, cert := range certs {
		fpSHA1, fpSHA256 := buildFingerprint(cert)

		chain = append(chain, models.CertDetail{
			CommonName:        cert.Subject.CommonName,
			Issuer:            cert.Issuer.CommonName,
			Organization:      cert.Subject.Organization,
			Country:           cert.Subject.Country,
			SANs:              cert.DNSNames,
			NotBefore:         cert.NotBefore,
			NotAfter:          cert.NotAfter,
			SerialNumberDec:   cert.SerialNumber.String(),
			SerialNumberHex:   cert.SerialNumber.Text(16),
			SignatureAlgo:     cert.SignatureAlgorithm.String(),
			FingerprintSHA1:   fpSHA1,
			FingerprintSHA256: fpSHA256,
			IsCA:              cert.IsCA,
		})
	}

	return chain
}
