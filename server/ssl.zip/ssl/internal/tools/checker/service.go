package checker

import (
	"tools.bctechvibe.io.vn/server/ssl/internal/config"
	"tools.bctechvibe.io.vn/server/ssl/internal/platform/breaker"
	"tools.bctechvibe.io.vn/server/ssl/internal/platform/cache"
	contextutil "tools.bctechvibe.io.vn/server/ssl/internal/platform/context"
	"tools.bctechvibe.io.vn/server/ssl/internal/platform/shared"
)

type Service struct {
	cache   *cache.MemoryCache
	breaker *breaker.CircuitBreaker
}

func New() *Service {
	return &Service{
		cache:   cache.NewMemoryCache(config.CacheTTL),
		breaker: breaker.New(),
	}
}

func (s *Service) Check(domain string) (interface{}, error) {

	if r, ok := s.cache.Get(domain); ok {
		return r, nil
	}

	if !s.breaker.Allow(domain) {
		return nil, shared.ErrBlocked
	}

	ctx, cancel := contextutil.New()
	defer cancel()

	res, err := Scan(ctx, domain)

	if err != nil {
		s.breaker.Fail(domain)
		return nil, err
	}

	s.breaker.Success(domain)
	s.cache.Set(domain, res)

	return res, nil
}
