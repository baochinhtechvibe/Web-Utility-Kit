package checker

import (
	"log"
	"net/http"
	"strings"

	"tools.bctechvibe.io.vn/server/ssl/internal/config"
)

func detectServerType(domain string) string {

	client := &http.Client{
		Timeout: config.HTTPHeadTimeout,
	}

	req, err := http.NewRequest(
		"HEAD",
		"https://"+domain,
		nil,
	)

	if err != nil {
		log.Printf("Server detection: failed to create HEAD request: %v", err)
		return "unknown"
	}

	resp, err := client.Do(req)
	if err != nil {
		log.Printf("Server detection: HEAD request failed: %v", err)
		return "unknown"
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK && resp.StatusCode != http.StatusNotFound {
		log.Printf("Server detection: server returned status %d", resp.StatusCode)
		return "unknown"
	}

	serverHeader := resp.Header.Get("Server")
	server := strings.ToLower(serverHeader)

	// Cloudflare detection
	if resp.Header.Get("CF-Ray") != "" ||
		strings.Contains(server, "cloudflare") {
		return "cloudflare"
	}

	// Known servers detection
	if strings.Contains(server, "nginx") {
		return normalizeServer(serverHeader, "nginx")
	}

	if strings.Contains(server, "apache") {
		return normalizeServer(serverHeader, "apache")
	}

	if strings.Contains(server, "litespeed") {
		return normalizeServer(serverHeader, "litespeed")
	}

	if strings.Contains(server, "openresty") {
		return normalizeServer(serverHeader, "openresty")
	}

	// Fallback to server header or unknown
	if serverHeader != "" {
		return serverHeader
	}

	return "unknown"
}
