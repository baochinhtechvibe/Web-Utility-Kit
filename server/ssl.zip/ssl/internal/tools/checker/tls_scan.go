package checker

import (
	"crypto/tls"
	"log"
	"net"

	"tools.bctechvibe.io.vn/server/ssl/internal/config"
	"tools.bctechvibe.io.vn/server/ssl/internal/models"
)

func scanTLS(domain string) []models.TLSScanResult {

	var results []models.TLSScanResult

	versions := []struct {
		Name string
		ID   uint16
	}{
		{config.TLSVersion13, tls.VersionTLS13},
		{config.TLSVersion12, tls.VersionTLS12},
		{config.TLSVersion11, tls.VersionTLS11},
		{config.TLSVersion10, tls.VersionTLS10},
	}

	for _, v := range versions {
		dialer := &net.Dialer{
			Timeout: config.TLSScanTimeout,
		}

		conn, err := tls.DialWithDialer(
			dialer,
			"tcp",
			domain+":443",
			&tls.Config{
				ServerName: domain,
				MinVersion: v.ID,
				MaxVersion: v.ID,
			},
		)

		if err != nil {
			log.Printf("TLS scan: %s not supported: %v", v.Name, err)
			continue
		}

		state := conn.ConnectionState()
		conn.Close()

		cipher := tls.CipherSuiteName(state.CipherSuite)
		secure := isSecureCipher(cipher)

		results = append(results, models.TLSScanResult{
			Version: v.Name,
			Cipher:  cipher,
			Secure:  secure,
		})
	}

	return results
}
