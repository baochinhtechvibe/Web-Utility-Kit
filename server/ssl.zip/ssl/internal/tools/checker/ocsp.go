package checker

import (
	"bytes"
	"crypto/x509"
	"io"
	"log"
	"net/http"

	"golang.org/x/crypto/ocsp"
	"tools.bctechvibe.io.vn/server/ssl/internal/config"
)

func checkOCSP(
	cert,
	issuer *x509.Certificate) bool {

	if len(cert.OCSPServer) == 0 {
		return false
	}

	req, err := ocsp.CreateRequest(
		cert,
		issuer,
		nil,
	)

	if err != nil {
		log.Printf("OCSP: failed to create request: %v", err)
		return false
	}

	client := http.Client{
		Timeout: config.OCSPCheckTimeout,
	}

	resp, err := client.Post(
		cert.OCSPServer[0],
		"application/ocsp-request",
		bytes.NewReader(req),
	)

	if err != nil {
		log.Printf("OCSP: request failed: %v", err)
		return false
	}
	defer resp.Body.Close()

	data, err := io.ReadAll(resp.Body)
	if err != nil {
		log.Printf("OCSP: failed to read response body: %v", err)
		return false
	}

	if resp.StatusCode != http.StatusOK {
		log.Printf("OCSP: server returned status %d", resp.StatusCode)
		return false
	}

	ocspResp, err := ocsp.ParseResponse(
		data,
		issuer,
	)

	if err != nil {
		log.Printf("OCSP: failed to parse response: %v", err)
		return false
	}

	if ocspResp.Status == ocsp.Good {
		return true
	}

	log.Printf("OCSP: certificate status is %d (not good)", ocspResp.Status)
	return false
}
