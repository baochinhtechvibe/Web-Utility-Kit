package router

import (
	"net/http"

	"tools.bctechvibe.io.vn/server/ssl/internal/config"
	"tools.bctechvibe.io.vn/server/ssl/internal/platform/middleware"
	"tools.bctechvibe.io.vn/server/ssl/internal/tools/checker"
)

type Router struct {
	limiter *middleware.RateLimiter
	breaker interface{} // Will be set by main
}

func Register() *Router {
	limiter := middleware.NewRateLimiter(
		config.RateLimitRequests,
		config.RateLimitWindow,
	)

	handler := &RateLimitHandler{
		limiter:     limiter,
		nextHandler: checker.NewHandler(),
	}

	http.Handle("/api/ssl/check", handler)

	return &Router{
		limiter: limiter,
	}
}

func (r *Router) Shutdown() {
	if r.limiter != nil {
		r.limiter.Stop()
	}
}

type RateLimitHandler struct {
	limiter     *middleware.RateLimiter
	nextHandler http.Handler
}

func (h *RateLimitHandler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	clientIP := h.limiter.GetClientIP(r.RemoteAddr, r.Header)

	if !h.limiter.IsAllowed(clientIP) {
		http.Error(w, "Too many requests", http.StatusTooManyRequests)
		return
	}

	h.nextHandler.ServeHTTP(w, r)
}
