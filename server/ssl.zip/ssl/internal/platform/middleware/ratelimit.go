package middleware

import (
	"net"
	"strings"
	"sync"
	"time"
)

type RateLimiter struct {
	visitors      map[string]*Visitor
	mu            sync.RWMutex
	limit         int
	window        time.Duration
	cleanupTicker *time.Ticker
	done          chan bool
}

type Visitor struct {
	count    int
	lastSeen time.Time
	mu       sync.Mutex
}

func NewRateLimiter(limit int, window time.Duration) *RateLimiter {
	rl := &RateLimiter{
		visitors:      make(map[string]*Visitor),
		limit:         limit,
		window:        window,
		cleanupTicker: time.NewTicker(window),
		done:          make(chan bool),
	}

	// Start cleanup routine
	go rl.cleanupRoutine()

	return rl
}

// GetClientIP extracts real client IP from request
func (rl *RateLimiter) GetClientIP(remoteAddr string, headers map[string][]string) string {
	// Check X-Forwarded-For (from proxies)
	if xff, ok := headers["X-Forwarded-For"]; ok && len(xff) > 0 {
		ips := strings.Split(xff[0], ",")
		if ip := strings.TrimSpace(ips[0]); isValidIP(ip) {
			return ip
		}
	}

	// Check X-Real-IP (from nginx)
	if xri, ok := headers["X-Real-IP"]; ok && len(xri) > 0 {
		if ip := strings.TrimSpace(xri[0]); isValidIP(ip) {
			return ip
		}
	}

	// Check CF-Connecting-IP (from Cloudflare)
	if cf, ok := headers["Cf-Connecting-IP"]; ok && len(cf) > 0 {
		if ip := strings.TrimSpace(cf[0]); isValidIP(ip) {
			return ip
		}
	}

	// Fallback to RemoteAddr
	if host, _, err := net.SplitHostPort(remoteAddr); err == nil {
		return host
	}

	return remoteAddr
}

// isValidIP validates IP format
func isValidIP(ip string) bool {
	return net.ParseIP(ip) != nil
}

// IsAllowed checks if client exceeded rate limit
func (rl *RateLimiter) IsAllowed(clientIP string) bool {
	rl.mu.Lock()
	defer rl.mu.Unlock()

	visitor, exists := rl.visitors[clientIP]
	if !exists {
		rl.visitors[clientIP] = &Visitor{
			count:    1,
			lastSeen: time.Now(),
		}
		return true
	}

	visitor.mu.Lock()
	defer visitor.mu.Unlock()

	if time.Since(visitor.lastSeen) > rl.window {
		visitor.count = 1
		visitor.lastSeen = time.Now()
		return true
	}

	visitor.count++
	visitor.lastSeen = time.Now()

	return visitor.count <= rl.limit
}

// cleanupRoutine removes expired visitors
func (rl *RateLimiter) cleanupRoutine() {
	for {
		select {
		case <-rl.cleanupTicker.C:
			rl.cleanup()
		case <-rl.done:
			rl.cleanupTicker.Stop()
			return
		}
	}
}

// cleanup removes visitors that haven't been seen recently
func (rl *RateLimiter) cleanup() {
	rl.mu.Lock()
	defer rl.mu.Unlock()

	now := time.Now()
	for ip, visitor := range rl.visitors {
		visitor.mu.Lock()
		if now.Sub(visitor.lastSeen) > rl.window*2 {
			delete(rl.visitors, ip)
		}
		visitor.mu.Unlock()
	}
}

// Stop stops the cleanup routine
func (rl *RateLimiter) Stop() {
	close(rl.done)
}
