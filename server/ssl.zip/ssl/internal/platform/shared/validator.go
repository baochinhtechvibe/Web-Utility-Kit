package shared

import (
	"net"
	"net/url"
	"regexp"
	"strings"

	"golang.org/x/net/idna"
	"tools.bctechvibe.io.vn/server/ssl/internal/config"
)

var domainRegex = regexp.MustCompile(
	`^(?i)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$`,
)

// NormalizeDomain extracts and normalizes domain from various formats
func NormalizeDomain(input string) string {
	d := strings.TrimSpace(input)

	// Decode URL encoded
	if u, err := url.QueryUnescape(d); err == nil {
		d = u
	}

	// Remove scheme
	d = strings.TrimPrefix(d, "http://")
	d = strings.TrimPrefix(d, "https://")

	// Remove path
	if i := strings.Index(d, "/"); i != -1 {
		d = d[:i]
	}

	// Remove port
	if i := strings.Index(d, ":"); i != -1 {
		d = d[:i]
	}

	return strings.ToLower(strings.TrimSpace(d))
}

// ValidDomain validates if input is a valid domain
func ValidDomain(input string) bool {
	d := NormalizeDomain(input)

	// Check if empty
	if len(d) == 0 {
		return false
	}

	// Check length
	if len(d) > config.MaxDomainLength {
		return false
	}

	// Try to parse as URL to get hostname
	if !strings.Contains(d, ".") {
		// Single label domain, try as IP
		if net.ParseIP(d) != nil {
			return true
		}
		return false
	}

	// Convert IDN to ASCII
	ascii, err := idna.ToASCII(d)
	if err != nil {
		return false
	}

	if len(ascii) == 0 || len(ascii) > config.MaxDomainLength {
		return false
	}

	// Validate ASCII domain
	return domainRegex.MatchString(ascii)
}
