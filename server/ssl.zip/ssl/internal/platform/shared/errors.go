package shared

import "errors"

var (
	ErrBlocked = errors.New("domain is temporarily blocked")
	ErrTimeout = errors.New("request timeout")
)
