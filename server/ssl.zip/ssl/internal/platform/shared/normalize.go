package shared

// This file is kept for backward compatibility
// All logic has been moved to validator.go
// Please use validator.go functions instead
